import java.io.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.FileWriter;

class App {
    static String censor(String text,
            String word) throws IOException {
        String stars = "";
        for (int i = 0; i < word.length(); i++)
            if (word.charAt(i) != ' ') {
                stars += '#';
            } else {
                stars += ' ';
            }
        text = text.replaceAll(word, stars);

        File path = new File("src\\newtextfile.txt");
        FileWriter wr = new FileWriter(path);
        wr.write(text);
        wr.flush();
        wr.close();
        System.out.println("\n\n\nText has been processed and stored in a new file in the current directory\n\n");
        System.out.println(text);
        return text;
    }

    public static void main(String[] args) throws IOException {
        Path fileName = Path.of("src\\textfile.txt");
        String extract = Files.readString(fileName);
        String cen = "consectetur adipiscing elit";
        censor(extract, cen);
    }
}
